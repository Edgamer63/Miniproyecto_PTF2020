package com.example.trabajoproyecto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoproyectoApplicationTests {

	@Test
	void contextLoads() {
	}

}
