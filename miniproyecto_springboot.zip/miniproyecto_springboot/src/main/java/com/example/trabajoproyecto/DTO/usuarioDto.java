package com.example.trabajoproyecto.DTO;

import java.util.Objects;

public class usuarioDto {
    private String correo;
    private String contraseña;

    public usuarioDto(String correo, String contraseña) {
        this.correo = correo;
        this.contraseña = contraseña;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    @Override
    public String toString() {
        return "usuarioDto{" +
                "correo='" + correo + '\'' +
                ", contrasenha='" + contraseña + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        usuarioDto that = (usuarioDto) o;
        return correo.equals(that.correo) &&
                contraseña.equals(that.contraseña);
    }

    @Override
    public int hashCode() {
        return Objects.hash(correo, contraseña);
    }

}