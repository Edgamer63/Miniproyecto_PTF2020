package com.example.trabajoproyecto.resource;

import com.example.trabajoproyecto.DAO.usuarioDao;
import com.example.trabajoproyecto.DTO.usuarioDto;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.List;


@RestController
@RequestMapping("/api")

public class proyectoResource {

    @RequestMapping(method = RequestMethod.GET, value = "/getUsers")
    public List<usuarioDto> obtenerUsuario() throws SQLException {
        List<usuarioDto> a = new usuarioDao().obtenerUsuarios();
        return a;
    }

    @RequestMapping(method = RequestMethod.GET, value = "/login/{correo}/{pass}")
    public String login(@PathVariable(name = "correo") String correo,@PathVariable(name = "pass") String pass) throws SQLException {
        List<usuarioDto> u = new usuarioDao().obtenerUsuarios();
        boolean correo_c=false,pass_c=false;
        int pos=0;
        String ret="-1";

        for (int i = 0;i<u.size();i++){
            if (u.get(i).getCorreo().equals(correo)){
                correo_c = true;
                pos = i;
                i = u.size();
            }
        }

        if (correo_c){
            if (u.get(pos).getContraseña().equals(pass)){
                pass_c=true;
            }
        }

        if (correo_c && pass_c){
            ret = "0";//Inicio de sesión correcto
        }else if (!pass_c){
            ret = "1";//Contraseña incorrecta
        }
        if (!correo_c){
            ret = "2";//Usuario no existe
        }

        return ret;
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getUsers/{correo}")
    public String obtenerUsuarioCorreo(@PathVariable(name = "correo") String correo) throws SQLException {
        String u = new usuarioDao().obtenerusuarioPorCorreo(correo);
        return u;
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/deleteUser/{correo}")
    public String borrarUsuario(@PathVariable(name = "correo") String correo) throws SQLException {
        new usuarioDao().borrarUsuario(correo);
        String s = "Se borró el usuario: "+correo;
        return s;
    }

    @RequestMapping(method = RequestMethod.POST, value = "/newUser/{correo}/{pass}")
    public String IngresarUsuario (@PathVariable(name = "correo") String correo,@PathVariable(name = "pass") String pass) throws SQLException {
        new usuarioDao().ingresarUsuario(correo,pass);
        return "Usuario Registrado Satisfactoriamente!";
    }

    @RequestMapping(method = RequestMethod.PUT, value = "/updateMail/{correoa}/{correo}")
    public String actualizarUsuario(@PathVariable("correoa") String correoa, @PathVariable("correo") String correo) throws SQLException {
        new usuarioDao().actualizarUsuario(correo, correoa);
        return "Se actualizó el usuario";
    }

    @RequestMapping(method = RequestMethod.PUT, value = "/updatePass/{correo}/{pass}")
    public String actualizarcontra(@PathVariable("correo") String correo,@PathVariable("pass") String pass) throws SQLException {
        new usuarioDao().actualizarContra(correo,pass);
        return "Se actualizó la contraseña";
    }
}
