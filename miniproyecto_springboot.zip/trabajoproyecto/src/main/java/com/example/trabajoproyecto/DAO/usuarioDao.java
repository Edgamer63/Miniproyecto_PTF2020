package com.example.trabajoproyecto.DAO;

import com.example.trabajoproyecto.ConnectionManager;
import com.example.trabajoproyecto.DTO.usuarioDto;

import java.sql.*;
import java.util.*;

public class usuarioDao {
    private Connection connection;

    public usuarioDao() throws SQLException {
        connection = ConnectionManager.obtenerConexion();
    }

    public String obtenerusuarioPorCorreo(String correo) throws SQLException {
        String consulta = "SELECT correo, contraseña FROM proyecto_grupo2 WHERE correo = ?";
        PreparedStatement ps = connection.prepareStatement(consulta);
        ps.setString(1, correo);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return "1";
        }
        return "0";
    }

    public List<usuarioDto> obtenerUsuarios() throws SQLException {
        List<usuarioDto> ret = new ArrayList<usuarioDto>();

        String consulta = "SELECT correo, contraseña FROM proyecto_grupo2";
        PreparedStatement ps = connection.prepareStatement(consulta);

        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            usuarioDto u = new usuarioDto(rs.getString ("correo"),rs.getString ("contraseña"));
            ret.add(u);
        }
        return ret;
    }

    public void borrarUsuario(String c) throws SQLException {
        String consulta = "DELETE FROM proyecto_grupo2 WHERE correo = ?";
        PreparedStatement ps = connection.prepareStatement(consulta);
        ps.setString(1, c);
        ps.execute();
    }

    public void ingresarUsuario(String c, String p) throws SQLException {
        String consulta = "INSERT INTO proyecto_grupo2 VALUES(?,?)";
        PreparedStatement ps = connection.prepareStatement(consulta);
        ps.setString(1, c);
        ps.setString(2, p);
        ps.execute();
    }

    public void actualizarUsuario(String correo, String correo_anterior) throws SQLException {
        String consulta = "UPDATE proyecto_grupo2 set correo=? where correo =?";
        PreparedStatement ps = connection.prepareStatement(consulta);
        ps.setString(1, correo);
        ps.setString(2, correo_anterior);
        ps.executeUpdate();
    }

    public void actualizarContra(String correo,String contraseña) throws SQLException {
        String consulta = "UPDATE proyecto_grupo2 set contraseña = ? where correo = ?";
        PreparedStatement ps = connection.prepareStatement(consulta);
        ps.setString(1, contraseña);
        ps.setString(2, correo);
        ps.executeUpdate();
    }
    /*
    public String login(String correo,String pass){
        String consulta = "SELECT correo as exists FROM proyecto_grupo2 where correo = ? and contraseña = ?";
        PreparedStatement ps = connection.prepareStatement(consulta);
        ps.setString(1, correo);
        ps.setString(2, pass);
        ps.executeUpdate();
    }
    */
}

