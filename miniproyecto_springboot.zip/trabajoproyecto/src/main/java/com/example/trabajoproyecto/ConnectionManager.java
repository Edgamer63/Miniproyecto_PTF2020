package com.example.trabajoproyecto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager {

    private static Connection connection = null;
    private static final String URL = "jdbc:postgresql://forgedb.netbyteoss.com:5443/forge_alumnos";

    public static Connection obtenerConexion() throws SQLException {
        if (connection == null) {
            connection = DriverManager.getConnection(URL, "epastene","P20.98");
        }
        return connection;
    }
}