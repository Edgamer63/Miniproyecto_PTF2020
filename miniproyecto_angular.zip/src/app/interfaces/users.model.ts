export interface Users {
    correo: string;
    pass: string;
}
