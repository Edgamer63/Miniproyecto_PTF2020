import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from'@angular/common/http';
import { Users } from '../interfaces/users.model';

@Injectable({
  providedIn: 'root'
})
export class UsersServiceService {
  constructor(private http: HttpClient) {

  }
  //URLgetUsers= 'http://localhost:8080/api/getUsers/';  // URL de obtener Usuarios
  //URLgetUsers= 'http://localhost:8080/api/getUsers/';  // URL de obtener Usuarios
  //`${this.apiUrl}/${nombre}`
  URL = 'http://localhost:8080/api/getUsers/';
  URL2 = 'http://localhost:8080/api/newUser/';
  URL3 = 'http://localhost:8080/api/updateMail/';
  URL4 = 'http://localhost:8080/api/deleteUser/';
  S="";

  /*
  */
  httpOptions = {
    headers: new HttpHeaders({'Content-Type': 'application/json'})
  };

  borrarUsuario(correo: String){
    return this.http.delete(this.URL4+`${correo}`,this.httpOptions);
  }

  obtenerUsuario(correo: String){
    return this.http.get(this.URL+`${correo}`,this.httpOptions);
  }

  cambiarUsuario(correoa:String,correo: String){
    return this.http.put(this.URL3+`${correoa}/${correo}`,this.httpOptions);
  }

  obtenerUsuarios(){
    return this.http.get<Users[]>(this.URL,this.httpOptions);
  }

  registrarUsuario(correo: String,pass: String){
    return this.http.post(this.URL2+`${correo}/${pass}`,this.httpOptions);
  }
  
}
