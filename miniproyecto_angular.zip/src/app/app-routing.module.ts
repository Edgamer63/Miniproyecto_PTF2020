import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {RegisterComponent} from './components/register/register.component';
import {BienvenidaComponent} from './components/bienvenida/bienvenida.component';
import {DeleteComponent} from './components/delete/delete.component';
const routes: Routes = [
  {
    path:'',
    component: BienvenidaComponent,
    pathMatch: 'full'
  },
  {
    path:'register',
    component: RegisterComponent
  },
  {
    path:'index',
    component: BienvenidaComponent
  },
  {
    path:'modify',
    component: DeleteComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
