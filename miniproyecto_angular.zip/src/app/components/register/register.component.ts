import { Component, OnInit } from '@angular/core';
import { UsersServiceService } from '../../services/users-service.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user="";
  pass="";
  
  letras = 0;
  numeros = 0;
  c_letras = false;//contiene
  c_numeros = false;//contiene
  passable = false;
  i=0;

  chars=0;

  existe;
  mensaje_registro;
  
  email_exists=false;

  user_exists;
  ret;
  constructor(private ser: UsersServiceService) { }

  ngOnInit(): void {
  }

  getUser(c: String){
    this.ret = this.ser.obtenerUsuario(c).subscribe(x => this.existe = x);
    this.email_exists=false;
    
    if (this.ret=="1"){
      this.email_exists=true;
    }
  }

  regUser(c: String,p: String){
    return this.ser.registrarUsuario(c,p).subscribe(x => this.mensaje_registro = x);
  }

  checkPass(){
    this.letras=0;
    this.numeros=0;
    this.passable = false;
    this.chars=this.pass.length;
    this.c_letras = false;//contiene
    this.c_numeros = false;//contiene
    for(this.i=0;this.i<this.pass.length;this.i++){
      if ((this.pass.charCodeAt(this.i) > 64 && this.pass.charCodeAt(this.i) < 91) || (this.pass.charCodeAt(this.i) > 96 && this.pass.charCodeAt(this.i) < 123)){
        this.letras++;
      }

      if ((this.pass.charCodeAt(this.i) > 47 && this.pass.charCodeAt(this.i) < 58)){
        this.numeros++;
      }
    }

    if (this.letras>0){
      this.c_letras = true;//contiene
    }

    if (this.numeros>0){
      this.c_numeros = true;//contiene
    }

    if (this.c_numeros && this.c_letras && this.chars >=4){
      this.passable = true;
    }
  }

}
