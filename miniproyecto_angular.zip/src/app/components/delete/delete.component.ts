import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { UsersServiceService } from '../../services/users-service.service';
import { Users } from '../../interfaces/users.model';


@Component({
  selector: 'app-delete',
  templateUrl: './delete.component.html',
  styleUrls: ['./delete.component.css']
})
export class DeleteComponent implements OnInit {

  Usuarios: Users [];// = [];

  updated_user;
  mod_user=false;
  mod_pass=false;

  user;
  new_user;
  new_pass;
  show_modify_user=false;
  show_modify_pass=false;
  i=-1;
  a=0;

  borrado;

  show_table=true;

  displayedColumns: string[] = ['correo'];
  mySubscription: any;

  constructor( private router: Router, private UserService: UsersServiceService ) {
    this.router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    }

    this.mySubscription = this.router.events.subscribe((event) => {
      if( event instanceof NavigationEnd ) {
        this.router.navigated = false;
      }
    });
  }
  ngOnDestroy(): void {
    if( this.mySubscription ) {
      this.mySubscription.unsubscribe();
    }
  }

  checkIfChangeableUser(){
    this.show_modify_user=false;
    this.i=this.new_user.charCodeAt(0);

    if (this.i>-1){
      /*
      //Sí, pensé en hacerlo como corresponde, y de hecho no funcionó por causas desconocidas
      for(this.a=0;this.a<this.new_user.length();this.a++){
        if (this.new_user.charCodeAt(this.a)==64){//64 en ascii es '@'
          this.show_modify_user=true;
        }
      }
      */
      this.show_modify_user=true;
    }
  }

  deleteUser(c: String){
    return this.UserService.borrarUsuario(c).subscribe(x => this.borrado = x);
  }

  triggerTableAgain(){
    this.mod_user=false;
    this.mod_pass=false;
    this.show_table=true;
  }

  triggerCambiarUsuario(c: string){
    this.mod_user=true;
    this.user = c;
    this.show_table=false;
  }
  cambiarUsuario(ca: String,c: String){
    this.mod_user=false;
    this.mod_pass=false;
    this.show_table=true;

    return this.UserService.cambiarUsuario(ca,c).subscribe(y => this.updated_user = y);
  }

  ngOnInit(): void {
    this.obtenerUsuarios();
  }

  obtenerUsuarios() {
    this.UserService.obtenerUsuarios().subscribe(a => this.Usuarios=a);
  }

}
